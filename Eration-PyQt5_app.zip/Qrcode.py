

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(672, 763)
        self.qrcode = QtWidgets.QLabel(Dialog)
        self.qrcode.setGeometry(QtCore.QRect(10, 30, 641, 621))
        self.qrcode.setFrameShape(QtWidgets.QFrame.Box)
        self.qrcode.setText("")
        self.qrcode.setTextFormat(QtCore.Qt.AutoText)
        self.qrcode.setPixmap(QtGui.QPixmap("PaytmQr.jpeg"))
        self.qrcode.setScaledContents(False)
        self.qrcode.setObjectName("qrcode")
        self.backbutton = QtWidgets.QPushButton(Dialog)
        self.backbutton.setGeometry(QtCore.QRect(220, 680, 141, 61))
        self.backbutton.setObjectName("backbutton")
        self.verifypayment = QtWidgets.QPushButton(Dialog)
        self.verifypayment.setGeometry(QtCore.QRect(390, 680, 261, 61))
        self.verifypayment.setObjectName("verifypayment")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Scan QR code"))
        self.backbutton.setText(_translate("Dialog", "Cancel"))
        self.verifypayment.setText(_translate("Dialog", "Verify Payment"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
