# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(780, 811)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(260, 0, 251, 81))
        self.label.setObjectName("label")
        self.ricebox = QtWidgets.QCheckBox(self.centralwidget)
        self.ricebox.setGeometry(QtCore.QRect(30, 100, 91, 61))
        self.ricebox.setObjectName("ricebox")
        self.sugarbox = QtWidgets.QCheckBox(self.centralwidget)
        self.sugarbox.setGeometry(QtCore.QRect(30, 190, 91, 71))
        self.sugarbox.setObjectName("sugarbox")
        self.kerosenebox = QtWidgets.QCheckBox(self.centralwidget)
        self.kerosenebox.setGeometry(QtCore.QRect(30, 290, 121, 61))
        self.kerosenebox.setObjectName("kerosenebox")
        self.oilbox = QtWidgets.QCheckBox(self.centralwidget)
        self.oilbox.setGeometry(QtCore.QRect(30, 370, 111, 61))
        self.oilbox.setObjectName("oilbox")
        self.fertilizersbox = QtWidgets.QCheckBox(self.centralwidget)
        self.fertilizersbox.setGeometry(QtCore.QRect(30, 440, 151, 101))
        self.fertilizersbox.setObjectName("fertilizersbox")
        self.wheatbox = QtWidgets.QCheckBox(self.centralwidget)
        self.wheatbox.setGeometry(QtCore.QRect(30, 570, 81, 51))
        self.wheatbox.setObjectName("wheatbox")
        self.saltbox = QtWidgets.QCheckBox(self.centralwidget)
        self.saltbox.setGeometry(QtCore.QRect(380, 110, 91, 51))
        self.saltbox.setObjectName("saltbox")
        self.purchasebutton = QtWidgets.QPushButton(self.centralwidget)
        self.purchasebutton.setGeometry(QtCore.QRect(420, 710, 121, 41))
        self.purchasebutton.setObjectName("purchasebutton")
        self.Price_Display = QtWidgets.QTextBrowser(self.centralwidget)
        self.Price_Display.setEnabled(False)
        self.Price_Display.setGeometry(QtCore.QRect(390, 260, 341, 281))
        self.Price_Display.setReadOnly(False)
        self.Price_Display.setObjectName("Price_Display")
        self.logoutbutton = QtWidgets.QPushButton(self.centralwidget)
        self.logoutbutton.setGeometry(QtCore.QRect(610, 710, 121, 41))
        self.logoutbutton.setObjectName("logoutbutton")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(500, 180, 211, 81))
        self.label_2.setObjectName("label_2")
        self.userinfo = QtWidgets.QPushButton(self.centralwidget)
        self.userinfo.setGeometry(QtCore.QRect(30, 710, 121, 41))
        self.userinfo.setObjectName("userinfo")
        self.clearbutton = QtWidgets.QPushButton(self.centralwidget)
        self.clearbutton.setGeometry(QtCore.QRect(220, 710, 131, 41))
        self.clearbutton.setObjectName("clearbutton")
        self.changepasswordbutton = QtWidgets.QPushButton(self.centralwidget)
        self.changepasswordbutton.setGeometry(QtCore.QRect(570, 600, 161, 51))
        self.changepasswordbutton.setObjectName("changepasswordbutton")
        self.qrice = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qrice.setGeometry(QtCore.QRect(190, 120, 71, 41))
        self.qrice.setAccelerated(True)
        self.qrice.setMaximum(10.0)
        self.qrice.setSingleStep(0.5)
        self.qrice.setStepType(QtWidgets.QAbstractSpinBox.DefaultStepType)
        self.qrice.setObjectName("qrice")
        self.qsugar = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qsugar.setGeometry(QtCore.QRect(190, 210, 71, 41))
        self.qsugar.setAccelerated(True)
        self.qsugar.setMaximum(10.0)
        self.qsugar.setSingleStep(0.5)
        self.qsugar.setObjectName("qsugar")
        self.qkerosene = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qkerosene.setGeometry(QtCore.QRect(190, 300, 71, 41))
        self.qkerosene.setAccelerated(True)
        self.qkerosene.setMaximum(10.0)
        self.qkerosene.setSingleStep(0.5)
        self.qkerosene.setObjectName("qkerosene")
        self.qoil = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qoil.setGeometry(QtCore.QRect(190, 380, 71, 41))
        self.qoil.setAccelerated(True)
        self.qoil.setMaximum(10.0)
        self.qoil.setSingleStep(0.5)
        self.qoil.setObjectName("qoil")
        self.qfertilizers = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qfertilizers.setGeometry(QtCore.QRect(190, 470, 71, 41))
        self.qfertilizers.setAccelerated(True)
        self.qfertilizers.setMaximum(10.0)
        self.qfertilizers.setSingleStep(0.5)
        self.qfertilizers.setObjectName("qfertilizers")
        self.qwheat = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qwheat.setGeometry(QtCore.QRect(190, 570, 71, 41))
        self.qwheat.setAccelerated(True)
        self.qwheat.setMaximum(10.0)
        self.qwheat.setSingleStep(0.5)
        self.qwheat.setObjectName("qwheat")
        self.qsalt = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.qsalt.setGeometry(QtCore.QRect(520, 120, 71, 41))
        self.qsalt.setAutoFillBackground(False)
        self.qsalt.setWrapping(False)
        self.qsalt.setFrame(True)
        self.qsalt.setAccelerated(True)
        self.qsalt.setMaximum(10.0)
        self.qsalt.setSingleStep(0.5)
        self.qsalt.setObjectName("qsalt")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 780, 18))
        self.menubar.setObjectName("menubar")
        self.menuHome = QtWidgets.QMenu(self.menubar)
        self.menuHome.setObjectName("menuHome")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menubar.addAction(self.menuHome.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Services"))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">SERVICES</span></p></body></html>"))
        self.ricebox.setText(_translate("MainWindow", "Rice"))
        self.sugarbox.setText(_translate("MainWindow", "Sugar"))
        self.kerosenebox.setText(_translate("MainWindow", "kerosene"))
        self.oilbox.setText(_translate("MainWindow", "oil"))
        self.fertilizersbox.setText(_translate("MainWindow", "Fertilizers"))
        self.wheatbox.setText(_translate("MainWindow", "Atta"))
        self.saltbox.setText(_translate("MainWindow", "Salt"))
        self.purchasebutton.setText(_translate("MainWindow", "Purchase"))
        self.Price_Display.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\';\">    </span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Rice          7 rs per kg</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Atta          26 rs per kg</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Sugar        13 rs per kg</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Salt           9 rs per kg</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">oil             30 rs per liter</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Kerosene   22 rs per liter</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Fertilizers   37 rs per bag</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:12pt;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:12pt;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:12pt;\"><br /></p></body></html>"))
        self.logoutbutton.setText(_translate("MainWindow", "LOGOUT"))
        self.label_2.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Prices</span></p></body></html>"))
        self.userinfo.setText(_translate("MainWindow", "User Info"))
        self.clearbutton.setText(_translate("MainWindow", "Clear"))
        self.changepasswordbutton.setText(_translate("MainWindow", "Change Password"))
        self.menuHome.setTitle(_translate("MainWindow", "Home"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
